require("dotenv").config();
const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const dataDir = path.join(__dirname, "data");
const uploadDir = path.join(__dirname, "public", "uploads");
fs.mkdirSync(dataDir, {recursive:true});
fs.mkdirSync(uploadDir, {recursive:true});
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  console.error("Set SESSION_SECRET to a random value of at least 32 characters.");
  process.exit(1);
}
if (!process.env.ADMIN_PASSWORD || process.env.ADMIN_PASSWORD.includes("replace-this")) {
  console.error("Set a strong ADMIN_PASSWORD in .env before starting.");
  process.exit(1);
}

const db = new Database(path.join(dataDir, "catalog.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT DEFAULT '',
 category TEXT NOT NULL, price TEXT DEFAULT '', availability TEXT NOT NULL DEFAULT 'Contact business',
 image TEXT DEFAULT '', published INTEGER NOT NULL DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS categories (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
`);
const defaultCats = ["Featured","Sparklers","Flower Pots","Fountains","Rockets","Other"];
for (const c of defaultCats) db.prepare("INSERT OR IGNORE INTO categories(name) VALUES(?)").run(c);
const settingDefaults = {
 business_name:"R. Kutiannan Fireworks",
 location:"Kumarapalayam, Tamil Nadu, India",
 phone:process.env.BUSINESS_PHONE || "",
 email:process.env.BUSINESS_EMAIL || "",
 address:process.env.BUSINESS_ADDRESS || "Kumarapalayam, Tamil Nadu, India",
 hours:"Please contact the business for current opening hours.",
 maps_url:process.env.GOOGLE_MAPS_URL || "",
 about:"R. Kutiannan Fireworks presents a curated catalog of business-approved products. Please contact the business to verify current product details, prices and availability."
};
for (const [k,v] of Object.entries(settingDefaults)) db.prepare("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)").run(k,v);

const adminHash = bcrypt.hashSync(process.env.ADMIN_PASSWORD, 12);
app.disable("x-powered-by");
app.use(helmet({contentSecurityPolicy:{directives:{
  defaultSrc:["'self'"], styleSrc:["'self'","'unsafe-inline'","https://fonts.googleapis.com"],
  fontSrc:["'self'","https://fonts.gstatic.com"], imgSrc:["'self'","data:"],
  scriptSrc:["'self'"], connectSrc:["'self'"], objectSrc:["'none'"], upgradeInsecureRequests:null
}}}));
app.use(express.json({limit:"1mb"}));
app.use(express.urlencoded({extended:false}));
app.use(session({
 secret:process.env.SESSION_SECRET, resave:false, saveUninitialized:false,
 store:new SQLiteStore({db:"sessions.sqlite",dir:dataDir}),
 cookie:{httpOnly:true,sameSite:"strict",secure:process.env.NODE_ENV==="production",maxAge:8*60*60*1000}
}));
app.use(express.static(path.join(__dirname,"public"),{extensions:["html"]}));

const loginLimiter = rateLimit({windowMs:15*60*1000,max:8,standardHeaders:true,legacyHeaders:false});
function requireAdmin(req,res,next){ if(req.session && req.session.admin) return next(); return res.status(401).json({error:"Administrator sign-in required."}); }
function csrf(req,res,next){
 if(["POST","PUT","DELETE"].includes(req.method) && req.path !== "/api/admin/login"){
   const token=req.get("x-csrf-token");
   if(!req.session.csrf || token !== req.session.csrf) return res.status(403).json({error:"Security token invalid. Refresh and try again."});
 }
 next();
}
app.use("/api",csrf);

app.get("/api/catalog",(req,res)=>{
 const products=db.prepare("SELECT id,name,description,category,price,availability,image FROM products WHERE published=1 ORDER BY id DESC").all();
 const categories=db.prepare("SELECT name FROM categories ORDER BY name").all().map(x=>x.name);
 const settings=Object.fromEntries(db.prepare("SELECT key,value FROM settings").all().map(x=>[x.key,x.value]));
 res.json({products,categories,settings});
});
app.post("/api/admin/login",loginLimiter,async(req,res)=>{
 const {username,password}=req.body||{};
 const suppliedUser=Buffer.from(String(username||""));
 const expectedUser=Buffer.from(String(process.env.ADMIN_USERNAME||"admin"));
 const validUser=suppliedUser.length===expectedUser.length && crypto.timingSafeEqual(suppliedUser,expectedUser);
 const validPass=await bcrypt.compare(String(password||""),adminHash);
 if(!validUser || !validPass) return res.status(401).json({error:"Incorrect username or password."});
 req.session.regenerate(err=>{
  if(err) return res.status(500).json({error:"Could not start secure session."});
  req.session.admin=true; req.session.csrf=crypto.randomBytes(32).toString("hex");
  res.json({ok:true,csrf:req.session.csrf});
 });
});
app.get("/api/admin/session",requireAdmin,(req,res)=>res.json({ok:true,csrf:req.session.csrf}));
app.post("/api/admin/logout",requireAdmin,(req,res)=>req.session.destroy(()=>res.json({ok:true})));

const storage=multer.diskStorage({
 destination:(req,file,cb)=>cb(null,uploadDir),
 filename:(req,file,cb)=>cb(null,crypto.randomUUID()+path.extname(file.originalname).toLowerCase())
});
const upload=multer({storage,limits:{fileSize:5*1024*1024},fileFilter:(req,file,cb)=>{
 const ok=["image/jpeg","image/png","image/webp"].includes(file.mimetype);
 cb(ok?null:new Error("Only JPG, PNG or WebP images are accepted."),ok);
}});
app.get("/api/admin/products",requireAdmin,(req,res)=>res.json(db.prepare("SELECT * FROM products ORDER BY id DESC").all()));
app.post("/api/admin/products",requireAdmin,upload.single("image"),(req,res)=>{
 const {name,description="",category,price="",availability="Contact business",published="1"}=req.body;
 if(!name || !category) return res.status(400).json({error:"Product name and category are required."});
 const image=req.file?"/uploads/"+req.file.filename:"";
 const result=db.prepare("INSERT INTO products(name,description,category,price,availability,image,published) VALUES(?,?,?,?,?,?,?)")
 .run(name,description,category,price,availability,image,published==="1"?1:0);
 res.json({ok:true,id:result.lastInsertRowid});
});
app.put("/api/admin/products/:id",requireAdmin,upload.single("image"),(req,res)=>{
 const old=db.prepare("SELECT * FROM products WHERE id=?").get(req.params.id);
 if(!old) return res.status(404).json({error:"Product not found."});
 const b=req.body, image=req.file?"/uploads/"+req.file.filename:old.image;
 db.prepare("UPDATE products SET name=?,description=?,category=?,price=?,availability=?,image=?,published=? WHERE id=?")
 .run(b.name||old.name,b.description??old.description,b.category||old.category,b.price??old.price,b.availability||old.availability,image,b.published==="0"?0:1,req.params.id);
 res.json({ok:true});
});
app.delete("/api/admin/products/:id",requireAdmin,(req,res)=>{
 const p=db.prepare("SELECT image FROM products WHERE id=?").get(req.params.id);
 if(p?.image?.startsWith("/uploads/")) fs.rm(path.join(__dirname,"public",p.image),{force:true},()=>{});
 db.prepare("DELETE FROM products WHERE id=?").run(req.params.id); res.json({ok:true});
});
app.get("/api/admin/categories",requireAdmin,(req,res)=>res.json(db.prepare("SELECT * FROM categories ORDER BY name").all()));
app.post("/api/admin/categories",requireAdmin,(req,res)=>{
 const name=String(req.body.name||"").trim();
 if(!name) return res.status(400).json({error:"Category name required."});
 try{db.prepare("INSERT INTO categories(name) VALUES(?)").run(name);res.json({ok:true});}
 catch(e){res.status(409).json({error:"That category already exists."});}
});
app.delete("/api/admin/categories/:id",requireAdmin,(req,res)=>{
 const c=db.prepare("SELECT name FROM categories WHERE id=?").get(req.params.id);
 if(!c) return res.status(404).json({error:"Category not found."});
 if(db.prepare("SELECT count(*) n FROM products WHERE category=?").get(c.name).n) return res.status(409).json({error:"Move or remove products in this category first."});
 db.prepare("DELETE FROM categories WHERE id=?").run(req.params.id);res.json({ok:true});
});
app.put("/api/admin/settings",requireAdmin,(req,res)=>{
 const allowed=["business_name","location","phone","email","address","hours","maps_url","about"];
 const update=db.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");
 for(const k of allowed) if(typeof req.body[k]==="string") update.run(k,req.body[k].slice(0,2000));
 res.json({ok:true});
});
app.use((err,req,res,next)=>{
 console.error(err.message);
 res.status(400).json({error:err.message || "Request could not be completed."});
});
app.listen(PORT,()=>console.log(`R. Kutiannan Fireworks running at http://localhost:${PORT}`));
